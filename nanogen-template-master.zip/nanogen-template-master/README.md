# nanogen-template

Template site built with [Nanogen](https://github.com/doug2k1/nanogen) and ready to be deployed to [Netlify](https://www.netlify.com) with the click of a button:

[![Deploy to Netlify](https://www.netlify.com/img/deploy/button.svg)](https://app.netlify.com/start/deploy?repository=https://github.com/doug2k1/nanogen-template)
